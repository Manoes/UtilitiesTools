class FaceData():
  def __init__(self):
    self.uvVertices = []
    self.geoIndices = []
    self.uvIndices = []
    self.deg = 0
    self.isPinned = False